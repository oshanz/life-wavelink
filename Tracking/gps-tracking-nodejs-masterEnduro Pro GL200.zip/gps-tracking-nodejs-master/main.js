var Cassandra = require('./lib/Cassandra');
var logger = require('./lib/Logger');
var gpsParser = require('./lib/GPSParser');
var net = require('net');
var express = require('express');

var app = express();
var cass = new Cassandra();
cass.connectToCassandra();


//Expose static files
app.configure(function() {
    app.use(express.static('./public'));
    app.use('/img',express.static('/public/img'));
	app.use('/js',express.static('/public/js'));
	app.use('/css',express.static('/public/css'));
});
 
//Make root index
app.get('/', function(req, res) {
  res.sendfile('./public/index.html');
});

//Get all devices, !!!! change to query from registered devices table later !!!!!, current method will cause consistency issues
app.get('/getalldevices', function(req, res) {
 	cass.queryForAllDevices(function (err,results){

 		distinctDevices = {};
 		results.forEach(function(row){ 
 			distinctDevices[row.get('device_id').value] = row.get('device_id').value;
         });

 		res.json(distinctDevices)
 	});

});

var httpServer = app.listen(8080);


//TCP socket to receive message for gps device, store them into Cassandra asynchronously and push new coordinate to browsers clients
var server = net.createServer(function(socket) {
  socket.on('end', function() {
    logger.info('TCP Server Disconnected');
  });

  socket.on('data', function(data) {
  	logger.info("Received TCP Message From: "+socket.remoteAddress)
    logger.info("Message: "+data.toString());

    ipAddress = socket.remoteAddress;
    

   	if(data.toString().split(',')[0] == '+RESP:GTFRI'){
	    gpsEntity = gpsParser.parseGL200(data.toString())
	    console.log(gpsEntity)
	    console.log("pushing for: "+gpsEntity.deviceName)
	    io.sockets.in(gpsEntity.deviceName).emit('newcoordinate', gpsEntity)
	    
	    cass.insertDeviceData(gpsEntity.deviceName, gpsEntity.imei, gpsEntity.sentTime, gpsEntity.sentTimeMillis, gpsEntity.receivedTime, gpsEntity.receivedTimeMillis, gpsEntity.batteryPercentage, gpsEntity.lat, gpsEntity.lng,ipAddress,  function(){
    		console.log("inserted")
    	})
	}
  });

});
server.listen(5555, function() { 
  logger.info('TCP Server Bound');
});


//Clients to choose which device to receive push notifications, will also push the latest coordinate to client
var io = require('socket.io').listen(app.listen(httpServer))
io.sockets.on('connection', function (socket) {
  socket.on('subscribetodevice', function (data) {
   	logger.info("listening for device: "+data.deviceId);
   	logger.info("stop listening to device: "+data.previousDeviceId);
   	socket.leave(data.previousDeviceId);
   	socket.join(data.deviceId);
   
   	cass.queryDeviceData(data.deviceId,1,function(err,results){

   		results.forEach(function(row){
   			console.log(new Date(row.get('sent_time_millis').value))

				gpsEntity = {
					imei : row.get('imei').value,
					deviceName: row.get('device_id').value,
					sentTimeMillis: row.get('sent_time_millis').value,
					receivedTimeMillis: row.get('received_time_millis').value,
					lat: row.get('lat').value,
					lng: row.get('lng').value,
					batteryPercentage: row.get('battery_percentage').value
				}
				socket.emit('newcoordinate', gpsEntity)
				console.log(gpsEntity)
		});
	});
  });
});

