#Real Time GPS Tracking With Node.js and Cassandra

Created this application to track my dog, its in the POC phase. The application currently support the Enduro Pro GL200 but it can easily support any device its just a matter writing a quick parser for the data format of that device. 

#Deployment: 


#Step 0 - Install Node

```
 Install node.js
 http://nodejs.org/

```

#Step 1 - Checkout

```
 Check out this project

```


#Step 2 - Installing Cassandra and Schema

```
 Install standard installation of cassandra anywhere
 From cassandra/bin folder run:
 ./cqlsh < /path to where the poject was checked out/gps-tracking-nodejs/schema

 Note: If you're not running as root you will have to create and give rw permissions to thsese folders manually 
 mkdir -p /var/lib/cassandra/data
 mkdir -p /var/lib/cassandra/commitlog
 mkdir -p /var/lib/cassandra/saved_caches
 chmod -R 644  /var/lib/cassandra/data
 chmod -R 644  /var/lib/cassandra/commitlog
 chmod -R 644  /var/lib/cassandra/saved_caches
 
```

#Step 3 - Installing node dependencies and running

```
 cd /path to where the poject was checked out/gps-tracking-nodejs
 npm install
 node main.js
 
```

#Step 4 - Testing

```
 Check at: localhost:8080
 
```

#Step 5 - GPS Device

```
 Configure gps device to you public ip port: 5555
 Note: If you're deploying it at home forward ports 8080, 5555, to the host you're working on.
 	   If you're on EC2 instances don't forget to open your ports
 
```



Roadmap:
Externalizing configurations
Authenication and access control





